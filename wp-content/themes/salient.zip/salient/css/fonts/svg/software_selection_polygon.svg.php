<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<g>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="19,59 16.675,59 15.851,57.261 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4.1609,2.0805" x1="14.661" y1="55.451" x2="2.851" y2="34.644"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="2.338,33.739 1.351,32 2.338,30.261 		
			"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4.1609,2.0805" x1="3.365" y1="28.451" x2="15.175" y2="7.644"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="15.851,6.739 16.675,5 19,5 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="21" y1="5" x2="44" y2="5"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="45,5 47.325,5 48.149,6.739 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4.1609,2.0805" x1="49.339" y1="8.549" x2="61.149" y2="29.356"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="61.662,30.261 62.649,32 61.662,33.739 
					"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4.1609,2.0805" x1="60.635" y1="35.549" x2="48.825" y2="56.356"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="48.149,57.261 47.325,59 45,59 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="43" y1="59" x2="20" y2="59"/>
	</g>
</g>
</svg>

<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="32" r="31"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="32" r="4"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M40.484,23.514C35.798,18.828,15,15,15,15
	s3.827,20.799,8.514,25.484c4.688,4.688,12.285,4.686,16.971,0C45.171,35.799,45.172,28.201,40.484,23.514z"/>
</svg>

<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<rect x="1" y="53" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="10" height="10"/>
<rect x="53" y="1" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="10" height="10"/>
<g>
	<g>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="44,22 44,20 42,20 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="40" y1="20" x2="23" y2="20"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="22,20 20,20 20,22 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="20" y1="24" x2="20" y2="41"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="20,42 20,44 22,44 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="24" y1="44" x2="41" y2="44"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="42,44 44,44 44,42 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="44" y1="40" x2="44" y2="23"/>
	</g>
</g>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="11" y1="53" x2="20" y2="44"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="44" y1="20" x2="53" y2="11"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="39" y1="32" x2="25" y2="32"/>
</svg>

<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="43" r="18"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M0,3c14,0,15,12,15,12s0,10,17,10"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M64,3C50,3,49,15,49,15s0,10-17,10"/>
</svg>

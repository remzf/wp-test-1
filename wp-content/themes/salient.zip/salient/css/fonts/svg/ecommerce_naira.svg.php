<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M53.92,10.081c12.107,12.105,12.107,31.732,0,43.838
	c-12.106,12.108-31.734,12.108-43.84,0c-12.107-12.105-12.107-31.732,0-43.838C22.186-2.027,41.813-2.027,53.92,10.081z"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="22,49 22,18 23,18 39,48 40,48 40,17 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="17" y1="30" x2="45" y2="30"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="17" y1="36" x2="45" y2="36"/>
</svg>

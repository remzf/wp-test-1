<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M56,45c4.19,0,7-2.81,7-7c0-4.189-2.81-9-7-9
	c0-10.475-9.525-18-20-18c-9.271,0-17.348,6.211-19,15c0,0-1.232,0-2,0c-5.238,0-9,4.762-9,10s3.762,9,9,9H56z"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M7.004,32.959c-1.59-1.017-2.943-2.37-3.961-3.96
	C1.75,26.979,1,24.577,1,22C1,14.82,6.82,9,14,9c4.604,0,8.646,2.392,10.957,6.001"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="20" y1="48" x2="12" y2="62"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="30" y1="48" x2="22" y2="62"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="40" y1="48" x2="32" y2="62"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="50" y1="48" x2="42" y2="62"/>
</svg>
